let menuBtn = document.querySelector(".menu_btn");
let menu = document.querySelector(".menu");



menuBtn.addEventListener("click", () => {
   menu.classList.toggle("active");
   menuBtn.classList.toggle("active");
});

nav = document.querySelector(".nav");

window.addEventListener('scroll', function () {
   if (window.scrollY > 100) {
      nav.classList.add('nav_active');
   } else {
      nav.classList.remove('nav_active');
   }
})


// closeBtn.addEventListener("click", () => {
//    menu.classList.remove("active");
//    closeBtn.classList.remove("active");
//    closeIcon.classList.remove('active')
//    menuBtn.classList.remove("hidden");
// });
// closeIcon.addEventListener("click", () => {
//    menu.classList.remove("active");
//    closeBtn.classList.remove("active");
//    closeIcon.classList.remove('active')
//    menuBtn.classList.remove("hidden");
// });


// let mouseDot = document.querySelector('.cursor_dot');

// window.addEventListener('mousemove', (e) => {
//    let x = e.clientX
//    let y = e.clientY;

//    console.log(x, y);

//    mouseDot.style.left = x - 10 + 'px'
//    mouseDot.style.top = y - 10 + 'px'

// })

// function dotBigger() {
//    mouseDot.classList.add('active');
// }
// function dotSmaller() {
//    mouseDot.classList.remove('active');
// }

// let dotClass = document.querySelectorAll('.dot');
// dotClass.forEach((el) => {
//    el.addEventListener('mouseenter', () => {
//       dotBigger()
//    })
//    el.addEventListener('mouseleave', () => {
//       dotSmaller()
//    })
// })

// let afterImage = document.querySelector('.afterimage')

// window.addEventListener('click', () => {
//    afterImage.classList.add('active');
//    setTimeout(() => {
//       afterImage.classList.remove('active');

//    }, 1000);
// })

let loader = document.querySelector('.preloader');
window.addEventListener('load', () => {
   setTimeout(() => {
      loader.classList.add('hide');

   }, 1000);
})

let squareBgc1 = document.querySelector('.square_bgc_1')
let firstRot = 40;
setInterval(() => {
   squareBgc1.style.transform = `rotate(${firstRot}deg)`;
   firstRot++;
}, 100);
let squareBgc2 = document.querySelector('.square_bgc_2')
let secondRot = 55;
setInterval(() => {
   squareBgc2.style.transform = `rotate(${secondRot}deg)`;
   secondRot--;
}, 100);



